package com.deutsche.tradestore.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "trade_data")
public class TradeEntity {
    @Id
    private String id;
    private Integer version;
    @Column(name = "counter_party_id")
    private String counterPartyId;
    @Column(name = "book_id")
    private String bookId;
    @Column(name = "maturity_date")
    private Date maturityDate;
    @Column(name = "creation_date")
    private Date creationDate;
    @Column(columnDefinition = "boolean default false")
    private Boolean expired;

}
