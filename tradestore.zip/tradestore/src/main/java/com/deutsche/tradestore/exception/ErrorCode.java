package com.deutsche.tradestore.exception;

public class ErrorCode {
    public static final String LOWER_VERSION_ERROR = "Discarding request as lower version entity received";
    public static final String INVALID_MATURITY_DATE_FORMAT = "Invalid maturity date format";
    public static final String OLDER_MATURITY_DATE = "Pass valid maturity date";
}
