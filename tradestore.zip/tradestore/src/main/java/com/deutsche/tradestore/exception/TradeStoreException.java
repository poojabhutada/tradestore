package com.deutsche.tradestore.exception;

public class TradeStoreException extends RuntimeException {

    public TradeStoreException(String message) {
        super(message);
    }
}
