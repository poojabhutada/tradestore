package com.deutsche.tradestore.model;


import lombok.Data;
import lombok.ToString;


@Data
@ToString
public class TradeRequest {
    private String id;
    private Integer version;
    private String counterPartyId;
    private String bookId;
    private String maturityDate;
}
