package com.deutsche.tradestore.repository;

import com.deutsche.tradestore.entity.TradeEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TradeRepository extends CrudRepository<TradeEntity, String> {
    @Query("SELECT e FROM TradeEntity e WHERE e.maturityDate < CURRENT_DATE and e.expired=false")
    Iterable<TradeEntity> findAllValid();
}
