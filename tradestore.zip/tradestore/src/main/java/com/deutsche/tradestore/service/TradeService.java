package com.deutsche.tradestore.service;

import com.deutsche.tradestore.entity.TradeEntity;
import com.deutsche.tradestore.exception.ErrorCode;
import com.deutsche.tradestore.exception.TradeStoreException;
import com.deutsche.tradestore.model.TradeRequest;
import com.deutsche.tradestore.repository.TradeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TradeService {

    private final TradeRepository tradeRepository;

    public void storeTrade(TradeRequest tradeRequest) {
        TradeEntity entity = new TradeEntity();
        Optional<TradeEntity> tradeEntity = tradeRepository.findById(tradeRequest.getId());
        if(tradeEntity.isPresent()) {
            if(tradeRequest.getVersion() < tradeEntity.get().getVersion()) {
                throw new TradeStoreException(ErrorCode.LOWER_VERSION_ERROR);
            }
            entity = tradeEntity.get();
        }

        Date maturityDate = getMaturityDate(tradeRequest);
        if(maturityDate.before(new Date())) {
            throw new TradeStoreException(ErrorCode.OLDER_MATURITY_DATE);
        }

        entity.setId(tradeRequest.getId());
        entity.setBookId(tradeRequest.getBookId());
        entity.setCounterPartyId(tradeRequest.getCounterPartyId());
        entity.setCreationDate(new Date());
        entity.setMaturityDate(maturityDate);
        entity.setVersion(tradeRequest.getVersion());
        entity.setExpired(false);
        tradeRepository.save(entity);
    }

    private Date getMaturityDate(TradeRequest tradeRequest) {
        try {
            return new Date(tradeRequest.getMaturityDate());
        }  catch (Exception e) {
            throw new TradeStoreException(ErrorCode.INVALID_MATURITY_DATE_FORMAT);
        }
    }
}
