package com.deutsche.tradestore.scheduler;

import com.deutsche.tradestore.entity.TradeEntity;
import com.deutsche.tradestore.repository.TradeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ExpiryManager {

    @Autowired
    private TradeRepository repository;

    @Scheduled(cron = "0 0 0 * * *")
    public void markTradeAsExpired() {
      // Scheduler written to run during midnight, and update the expired flag to true for all the records where maturity date has crossed the current date
        Iterable<TradeEntity> tradeEntities = repository.findAllValid();
        tradeEntities.forEach(entity -> {
           entity.setExpired(true);
           repository.save(entity);
           log.info("Marked entity with id : {} as expired", entity.getId());
        });
    }

}
