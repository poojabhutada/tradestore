package com.deutsche.tradestore.controller;


import com.deutsche.tradestore.model.TradeRequest;
import com.deutsche.tradestore.service.TradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class TradeController {

    @Autowired
    private TradeService tradeService;

    @PostMapping("/create")
    public void createTrade(@RequestBody TradeRequest tradeRequest) {
    	// Call service to save the trade request passed in input
        tradeService.storeTrade(tradeRequest);
    }

}
