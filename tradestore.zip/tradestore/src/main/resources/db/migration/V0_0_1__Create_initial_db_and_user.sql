CREATE SCHEMA IF NOT EXISTS "test_db";

CREATE USER IF NOT EXISTS test PASSWORD 'test' ADMIN;


CREATE TABLE trade_data (
    `id`                         varchar(10),
    `version`                    int(2)   NOT null,
    `counter_party_id`           varchar(20)  NOT null,
    `book_id`                    varchar(20)  NOT null,
    `maturity_date`              DATE NULL NOT null,
    `creation_date`              DATE DEFAULT CURRENT_DATE NOT null,
    `expired`                    BOOLEAN default false,
    primary key (`id`)
);