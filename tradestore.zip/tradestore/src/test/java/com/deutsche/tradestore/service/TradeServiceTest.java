package com.deutsche.tradestore.service;


import com.deutsche.tradestore.entity.TradeEntity;
import com.deutsche.tradestore.exception.TradeStoreException;
import com.deutsche.tradestore.model.TradeRequest;
import com.deutsche.tradestore.repository.TradeRepository;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Date;
import java.util.Optional;

public class TradeServiceTest {

    private TradeRepository tradeRepository = Mockito.mock(TradeRepository.class);
    private TradeService tradeService = new TradeService(tradeRepository);

    @Test
    public void saveValidRequest() {
        TradeRequest tradeRequest = new TradeRequest();
        tradeRequest.setId("T1");
        tradeRequest.setBookId("B1");
        tradeRequest.setCounterPartyId("C1");
        tradeRequest.setMaturityDate("10/10/2021");
        tradeRequest.setVersion(1);
        tradeService.storeTrade(tradeRequest);
    }


    @Test(expected = TradeStoreException.class)
    public void olderMaturityDate() {
        TradeRequest tradeRequest = new TradeRequest();
        tradeRequest.setId("T1");
        tradeRequest.setBookId("B1");
        tradeRequest.setCounterPartyId("C1");
        tradeRequest.setMaturityDate("10/10/2020");
        tradeRequest.setVersion(1);
        tradeService.storeTrade(tradeRequest);
    }


    @Test(expected = TradeStoreException.class)
    public void olderVersion() {

        TradeEntity tradeRequestOld = new TradeEntity();
        tradeRequestOld.setId("T1");
        tradeRequestOld.setBookId("B1");
        tradeRequestOld.setCounterPartyId("C1");
        tradeRequestOld.setMaturityDate(new Date());
        tradeRequestOld.setVersion(2);
        tradeRequestOld.setExpired(false);
        Mockito.when(tradeRepository.findById("T1")).thenReturn(Optional.of(tradeRequestOld));


        TradeRequest tradeRequest = new TradeRequest();
        tradeRequest.setId("T1");
        tradeRequest.setBookId("B1");
        tradeRequest.setCounterPartyId("C1");
        tradeRequest.setMaturityDate("10/10/2020");
        tradeRequest.setVersion(1);
        tradeService.storeTrade(tradeRequest);
    }

}
